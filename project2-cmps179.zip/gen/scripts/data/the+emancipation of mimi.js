{
'totalBidsRecords': 0,
'totalBidsCds': 2,
'totalCountSoldRecords': 1,
'totalCountSoldCds': 72,
'averageRevenueCds': 10.04833333333334,
'averageRevenueRecords': 74.99,
'label': 'the emancipation of mimi'
}