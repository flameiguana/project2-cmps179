{
'totalBidsRecords': 1,
'totalBidsCds': 39,
'totalCountSoldRecords': 7,
'totalCountSoldCds': 160,
'averageRevenueCds': 4.246750000000003,
'averageRevenueRecords': 24.005714285714287,
'label': 'jagged little pill'
}