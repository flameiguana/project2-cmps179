{
'totalBidsRecords': 9,
'totalBidsCds': 81,
'totalCountSoldRecords': 1,
'totalCountSoldCds': 28,
'averageRevenueCds': 8.29892857142857,
'averageRevenueRecords': 12.5,
'label': 'tornado little big town'
}