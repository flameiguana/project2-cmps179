{
'totalBidsRecords': 0,
'totalBidsCds': 3,
'totalCountSoldRecords': 2,
'totalCountSoldCds': 26,
'averageRevenueCds': 18.87807692307692,
'averageRevenueRecords': 22.285,
'label': 'pink friday reloaded'
}