{
'totalBidsRecords': 55,
'totalBidsCds': 67,
'totalCountSoldRecords': 8,
'totalCountSoldCds': 35,
'averageRevenueCds': 14.877142857142855,
'averageRevenueRecords': 29.929999999999996,
'label': 'all eyez on me '
}