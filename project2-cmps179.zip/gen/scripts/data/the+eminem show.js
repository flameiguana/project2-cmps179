{
'totalBidsRecords': 13,
'totalBidsCds': 41,
'totalCountSoldRecords': 2,
'totalCountSoldCds': 59,
'averageRevenueCds': 5.090508474576271,
'averageRevenueRecords': 117.995,
'label': 'the eminem show'
}