{
'totalBidsRecords': 435,
'totalBidsCds': 111,
'totalCountSoldRecords': 369,
'totalCountSoldCds': 180,
'averageRevenueCds': 34.18761111111103,
'averageRevenueRecords': 83.45712737127437,
'label': 'michael jackson thriller'
}