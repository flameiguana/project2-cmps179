{
'totalBidsRecords': 2,
'totalBidsCds': 226,
'totalCountSoldRecords': 17,
'totalCountSoldCds': 101,
'averageRevenueCds': 12.14673267326733,
'averageRevenueRecords': 20.748823529411766,
'label': 'adele 21'
}