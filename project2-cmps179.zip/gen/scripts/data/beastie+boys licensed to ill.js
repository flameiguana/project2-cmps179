{
'totalBidsRecords': 65,
'totalBidsCds': 14,
'totalCountSoldRecords': 22,
'totalCountSoldCds': 57,
'averageRevenueCds': 4.129122807017545,
'averageRevenueRecords': 114.59818181818181,
'label': 'beastie boys licensed to ill'
}