{
'totalBidsRecords': 0,
'totalBidsCds': 0,
'totalCountSoldRecords': 0,
'totalCountSoldCds': 0,
'averageRevenueCds': NaN,
'averageRevenueRecords': NaN,
'label': 'garth brooks 1981'
}