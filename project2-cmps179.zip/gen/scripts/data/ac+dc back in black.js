{
'totalBidsRecords': 140,
'totalBidsCds': 96,
'totalCountSoldRecords': 114,
'totalCountSoldCds': 112,
'averageRevenueCds': 14.163750000000006,
'averageRevenueRecords': 18.853508771929825,
'label': 'ac dc back in black'
}