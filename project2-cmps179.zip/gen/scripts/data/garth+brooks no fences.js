{
'totalBidsRecords': 0,
'totalBidsCds': 21,
'totalCountSoldRecords': 0,
'totalCountSoldCds': 60,
'averageRevenueCds': 4.218000000000002,
'averageRevenueRecords': NaN,
'label': 'garth brooks no fences'
}