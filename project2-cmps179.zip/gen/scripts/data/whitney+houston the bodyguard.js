{
'totalBidsRecords': 0,
'totalBidsCds': 5,
'totalCountSoldRecords': 12,
'totalCountSoldCds': 39,
'averageRevenueCds': 6.462820512820512,
'averageRevenueRecords': 45.64333333333334,
'label': 'whitney houston the bodyguard'
}