{
'totalBidsRecords': 0,
'totalBidsCds': 0,
'totalCountSoldRecords': 1,
'totalCountSoldCds': 4,
'averageRevenueCds': 5.61,
'averageRevenueRecords': 20,
'label': 'garth brooks self titled'
}