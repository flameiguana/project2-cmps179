{
'totalBidsRecords': 134,
'totalBidsCds': 97,
'totalCountSoldRecords': 47,
'totalCountSoldCds': 63,
'averageRevenueCds': 21.454285714285717,
'averageRevenueRecords': 70.21063829787231,
'label': 'hybrid theory'
}