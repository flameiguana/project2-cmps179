{
'totalBidsRecords': 12,
'totalBidsCds': 115,
'totalCountSoldRecords': 25,
'totalCountSoldCds': 63,
'averageRevenueCds': 10.867142857142861,
'averageRevenueRecords': 53.03160000000002,
'label': 'black keys el camino'
}